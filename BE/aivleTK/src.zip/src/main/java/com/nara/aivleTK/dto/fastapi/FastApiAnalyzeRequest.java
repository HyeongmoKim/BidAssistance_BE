package com.nara.aivleTK.dto.fastapi;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FastApiAnalyzeRequest {
    private String text;       // 분석할 텍스트 (Bid 정보 + BidDetail 정보)
    private String threadId;   // 스레드 ID (기본값: bidId)
}